function Next = EnvSel_PDMOEA_AR(FrontValue,SRANK,PRANK,K)

N                   = length(FrontValue);
Next                = false(1,N);

[~,Rank]            = sortrows([FrontValue',PRANK,SRANK]);
ranked              = Rank(1:K);
Next(ranked)        = true;


end

