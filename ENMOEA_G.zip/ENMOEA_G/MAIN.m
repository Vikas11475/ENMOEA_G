% The code of ENMOEA_G
format compact;tic;
%-----------------------------------------------------------------------------------------
% Parameters setting
for Problem = 1 : 7 % test problem
    
    for M = [5 8 10 15 20]  % number of objectives
        
        if Problem == 1 % DTLZ1
            K = 5;  % the parameter in DTLZ1
        elseif Problem == 2 || 3 || 4
            K = 10;  % the parameter in DTLZ2, DTLZ3, DTLZ4,
        elseif Problem == 5 || 6
            K = 10;  % the parameter in DTLZ5, DTLZ6
        elseif Problem == 7 % DTLZ7
            K = 20;  % the parameter in DTLZ7
        end
        
        %% Number of Generations
        if Problem == 1
            if M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 550;
            elseif M == 20
                Generations = 600;
            end
        end
        
        if Problem == 2
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        
        if Problem == 3
            if M == 5
                Generations = 500;
            elseif M == 8
                Generations = 500;
            elseif M == 10
                Generations = 500;
            elseif M == 15
                Generations = 550;
            elseif M == 20
                Generations = 600;
            end
        end
        
        if Problem == 4
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        
        if Problem == 5
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        
        if Problem == 6
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        
        if Problem == 7
            if M == 5
                Generations = 250;
            elseif M == 8
                Generations = 250;
            elseif M == 10
                Generations = 250;
            elseif M == 15
                Generations = 300;
            elseif M == 20
                Generations = 320;
            end
        end
        %% Population size
        if M == 2
            N = 100;            % population size
        elseif M == 3
            N = 120;
        elseif M == 5
            N = 126;
        elseif M == 8
            N = 156;
        elseif M == 10
            N = 275;
        elseif M == 15
            N = 240;
        elseif M == 20
            N = 230;
        end
        
        D = M + K - 1;
        
        MinValue   = zeros(1,D);
        MaxValue   = ones(1,D);
        Boundary   = [MaxValue;MinValue];
        Runs       =  30; 
        %-------------------------------------------------------------------------------------------------------------------------------
        for run = 1 : Runs
            % Initialization
            Population            = repmat(MinValue,N,1) + repmat(MaxValue - MinValue,N,1).*rand(N,D); % initial population
            FunctionValue         = F_DTLZ(Population,Problem,M, K);	% calculate the objective values
            [FrontValue,MaxFront] = NDSort(FunctionValue,inf);               % non-dominated sort using A-ENS
            [RPSet,N1]             = UniformPoint(N,M);
            
            %% repair the number of solutions
            if length(RPSet)< N
                mn    = N - length(RPSet);
                nn    = randi(mn,[mn,1]);
                nm    = RPSet(nn,:);
                RPSet = [RPSet;nm];
            end
            
            %PDMOEA_MR
            [SRANK,PRANK]         = SPRANK(FunctionValue,FrontValue,MaxFront);
            
            %ISDEPlus
            Dist_ISDEPlus         = F_ISDEplus(FunctionValue);
            
            % RPD_NSGAII
            [~,FrontNo_RPD,d2]    =  EnvSel_RPD_NSGAII(FunctionValue,RPSet,N);
            ArchiveP  = [];
            ArchiveF  = [];
            
            %% initial population
            Wt        = [0.33 0.33 0.33];
            VV        = ceil(N*0.33);
            N_sel     = [VV VV VV];
            
            if sum(N_sel,2) < N
                for i   = 1 : N-sum(N_sel,2)
                    ind  = randi(length(N_sel));
                    indx = N_sel(ind);
                    indx = indx+1;
                    N_sel(ind) = indx;
                end
            end
            
            %-----------------------------------------------------------------------------------------
            % Main iterations
            for Gene = 1 : Generations
                %% Mating selection
                % Mating Selection using PDMOEA_MR
                Mating_PDMOEA_AR    = F_mating_PDMOEA_AR(FrontValue,PRANK);
                
                % Mating Selection using ISDE+
                Mating_ISDEplus     = F_matingISDEplus(FunctionValue,Dist_ISDEPlus);
                
                % Mating Selection using RPD_NSGAII
                Mating_RPD_NSGAII    = TournamentSelection(2,N,FrontNo_RPD,d2);
                %% Offspring Generation
                
                N1                    = N_sel(1);
                N2                    = N_sel(2);
                N3                    = N_sel(3);
                
                M1                    = Mating_PDMOEA_AR(1:N1);
                M2                    = Mating_ISDEplus(1:N2);
                M3                    = Mating_RPD_NSGAII(1:N3);
                
                Off1                  = GA(Population(M1,:),{1,20,1,20},MinValue,MaxValue);
                Off2                  = GA(Population(M2,:),{1,20,1,20},MinValue,MaxValue);
                Off3                  = GA(Population(M3,:),{1,20,1,20},MinValue,MaxValue);
                
                N1_off                = size(Off1,1);
                N2_off                = size(Off2,1);
                N3_off                = size(Off3,1);
                %% PDMOEA-AR
                if  N1_off > N1
                    rem_sol1         = randi(N1,[1,1]);
                    Off1(rem_sol1,:)  = [];
                elseif N1_off < N1
                    req_sol1         = randi(N1,[2,1]);
                    r_sol1           = GAhalf(Population(req_sol1,:),{1,20,1,20},MinValue,MaxValue,'real');
                    Off1             = [Off1;r_sol1];
                end
                
                %% ISDEplus
                if  N2_off > N2
                    rem_sol2         = randi(N2,[1,1]);
                    Off2(rem_sol2,:)  = [];
                elseif N2_off < N2
                    req_sol2         = randi(N2,[2,1]);
                    r_sol2           = GAhalf(Population(req_sol2,:),{1,20,1,20},MinValue,MaxValue,'real');
                    Off2             = [Off2;r_sol2];
                end
                
                %% RPD-NSGAII
                if  N3_off > N3
                    rem_sol3         = randi(N3,[1,1]);
                    Off3(rem_sol,:)  = [];
                elseif N3_off < N3
                    req_sol3         = randi(N3,[2,1]);
                    r_sol3           = GAhalf(Population(req_sol3,:),{1,20,1,20},MinValue,MaxValue,'real');
                    Off3             = [Off3;r_sol3];
                end
                
                
                Offspring             = [Off1;Off2;Off3];
                N_off                 = size(Offspring,1);
                NewF                  = F_DTLZ(Offspring,Problem,M, K);    % calculate the objective values
                %% Combining Populations
                Population            = [Population;Offspring;ArchiveP];
                FunctionValue         = [FunctionValue;NewF;ArchiveF];
                %% Nondominated sorting
                [FrontValue,MaxFront]    = NDSort(FunctionValue,N);
                %% Distance calculation for ISDEplus
                Dist_ISDEPlus            = F_ISDEplus(FunctionValue);
                %% environmental selection
                % environmental selection using PDMOEA_MR
                [SRANK,PRANK]                 = SPRANK(FunctionValue,FrontValue,MaxFront);
                Next_PDMOEA_AR                = EnvSel_PDMOEA_AR(FrontValue,SRANK,PRANK,N);
                % environmental selection using ISDE+
                Next_ISDEplus                 = EnvSel_ISDEplus(Dist_ISDEPlus,N);
                
                % environmental selection using RPD_NSGAII
                [Next_RPD_NSGAII,FrontNo_RPD,d2]  = EnvSel_RPD_NSGAII(FunctionValue,RPSet,N);
                
                %% Environmental Selection of multi-algorithm
                Next_comb                        = [Next_PDMOEA_AR', Next_ISDEplus',Next_RPD_NSGAII'];
                [Next_all,Preserved]             = Environmental_selection(Next_comb,N);
                [N_sel,Wt]                       = adap_probability(Next_all,N_sel,Wt,N);
                
                %% Archive population
                ArchiveP                         = Population(Preserved,:);
                ArchiveF                         = FunctionValue(Preserved,:);
                %% population for next generation
                Population       = Population(Next_all,:);     % solutions on decision space
                FunctionValue    = FunctionValue(Next_all,:);  % solutions on objective space
                FrontValue       = FrontValue(Next_all);       % the front number of each solution
                PRANK            = PRANK(Next_all);
                Dist_ISDEPlus    = Dist_ISDEPlus(Next_all);
                FrontNo_RPD      = FrontNo_RPD(Next_all);
                d2               = d2(Next_all);
                Gene
            end
            F_output(Population,toc,'ENMOEA_G_DTLZ',Problem,M,K,run);
        end
    end
    clear all;clc
end
